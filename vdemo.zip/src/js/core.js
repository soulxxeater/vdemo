// core.js
module.exports = {};